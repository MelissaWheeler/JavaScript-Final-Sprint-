
// Step 3: Read the JSON file using Fetch API
fetch('data.json')
  .then(response => response.json())
  .then(data => {
    console.log(data); // Print JSON data to console
    
    // Step 4: Iterate over records and display a key-value pair
    data.forEach(record => {
      console.log(record); // Print each record to console
    });
    
    // Step 5: Create functions to describe JSON data
    function getTotalRecords() {
      return `Total number of records: ${data.length}`;
    }
    
    function getFirstRecord() {
      return `First record: ${JSON.stringify(data[0])}`;
    }
    
    function getLastRecord() {
      return `Last record: ${JSON.stringify(data[data.length - 1])}`;
    }
    
    // Display JSON data in browser window
    const jsonDataDiv = document.getElementById('json-data');
    jsonDataDiv.innerHTML = `<p>${getTotalRecords()}</p>`;
    jsonDataDiv.innerHTML += `<p>${getFirstRecord()}</p>`;
    jsonDataDiv.innerHTML += `<p>${getLastRecord()}</p>`;
  })
  .catch(error => console.error('Error reading JSON file:', error));
